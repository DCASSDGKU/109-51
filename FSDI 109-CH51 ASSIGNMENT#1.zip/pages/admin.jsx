import "./styles/admin.css";

function Admin(){
    return(
        <div className="admin page">
            <h3>Store Management</h3>
        </div>
    )
}

export default Admin;