import "./styles/cart.css";

function Cart() {
    return (
        <div className="cart page">
            <h1>Ready to complete the order?</h1>
        </div>
    );
}

export default Cart;