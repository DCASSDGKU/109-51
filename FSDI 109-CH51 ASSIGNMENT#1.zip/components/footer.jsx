import "./styles/footer.css";

function footer(){
    return(
        <div className="footer">
            <footer className="content">
                <hr />
                <div>
                    <span>Created by: Dennis Casiguran</span>
                </div>
            </footer>
        </div>
    );
}

export default footer;