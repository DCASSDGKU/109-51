import { useState } from 'react';
import DataContext from './dataContext';

function GlobalProvider(props){
    const [cart, setCart] = useState([]);
    const [user, setUser] = useState({});

    function addToCart(){
    }

    function removeFromCart(){
    }

    function clearCart(){
    }

    return(
        <DataContext.Provider value={{ 
            cart: cart,
            user: user,
            addToCart: addToCart,
            removeFromCart: clearCart,
            clearCart: clearCart
            
        }}>
            {props.children}
        </DataContext.Provider>
    );
}

export default GlobalProvider;