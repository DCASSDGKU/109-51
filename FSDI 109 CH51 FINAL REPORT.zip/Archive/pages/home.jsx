import "./styles/home.css";

//import backIMG from "../assets/top-banner.jpg"
import { Link } from 'react-router-dom';


function Home(){
    return (
        <div className="home page">

            {/* opt 1, with image in public folder */}
            <img src='/images/wrap2.jpg' alt="" />

            <div className="home-text">
                <h1>All in One Store</h1>

                <Link className='btn btn-success' to="/catalog">Check our amazing catalog</Link>   
            </div>
            
        

            {/* opt 2, with image in src and imported */}

        </div>
    )
}

export default Home;