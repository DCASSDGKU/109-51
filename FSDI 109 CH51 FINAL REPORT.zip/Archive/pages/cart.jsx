import { useContext } from 'react';
import "./styles/cart.css";
import DataContext from '../state/dataContext';

function Cart() {

    const globalCart = useContext(DataContext).cart;

    function getTotal() {
        let total = 0;
        for(let i=0; i < globalCart.length; i++){
            const prod = globalCart[i];
            total += (prod.quantity * prod.price);
        }
    }

    return (
        
        <div className="cart page">
            <h1>Ready to complete the order?</h1>
        
            
            <div className="list">
                {globalCart.map( prod => 
                    <div className='cart-prod'>
                        <img src={prod.image} alt=""></img> 
                        <h4>{prod.title}</h4>
                        <label>${prod.price}</label>
                        <label>#{prod.quantity}</label>
                        <label>${prod.price * prod.quantity}</label>
                        <button className='btn btn-sm btn-outline-danger'>Remove</button>

                    </div>

                    
                )}

            </div>

        </div>
    );
}

export default Cart;