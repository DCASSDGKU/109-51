# Mini Challenge 1
- Create a new component called "footer"
- create a new css file to link the new rules
- Add the new component to the root component
- Add to the footer "Created by: YOUR_NAME"