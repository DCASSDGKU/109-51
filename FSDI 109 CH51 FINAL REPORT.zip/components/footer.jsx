import "./styles/footer.css";

function footer(){
    return(
        <div className="footer">
            <footer className="content">
                <hr />
                <div>
                    <h5>The Secret Fresh</h5>
                    <h6>Don't Panic It's Organic!</h6>
                </div>
            </footer>
        </div>
    );
}

export default footer;